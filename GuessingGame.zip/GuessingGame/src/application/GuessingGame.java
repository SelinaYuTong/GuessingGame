package application;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public class GuessingGame extends Application {
	private final TextField usersNum = new TextField();
	private final Label feedback = new Label();
	private int total = 5, target;

	@Override
	public void start(Stage stage) {
		// set the bar title
		stage.setTitle("A Guessing Game");
		try {
			// set the icon
			Image icon = new Image(new FileInputStream("game.png"));
			stage.getIcons().add(icon);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// set the feedback label
		feedback.setText("Welcome!Let's play!");
		feedback.setFont(Font.font("Verdana", 20));
		feedback.setPrefSize(250, 120);
		feedback.setTextAlignment(TextAlignment.CENTER);
		feedback.setWrapText(true);

		// set the text field
		usersNum.setPrefWidth(220);
		usersNum.setPromptText("Enter a number between 1 and 100.");
		usersNum.setFocusTraversable(false);

		// set the two buttons
		Image im1 = new Image(getClass().getResourceAsStream("submit.png"));
		ImageView iv1 = new ImageView(im1);
		Button submitButton = new Button("Submit", iv1);
		submitButton.setFont(Font.font("Arial", 24));

		Image im2 = new Image(getClass().getResourceAsStream("restart.png"));
		ImageView iv2 = new ImageView(im2);
		Button restartButton = new Button("Restart", iv2);
		restartButton.setFont(Font.font("Arial", 24));

		// store the target number
		target = (int) Math.floor(Math.random() * 100) + 1;
		// submit button action
		submitButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				// comment out the line below before the real player starts to play
				System.out.println("(For testing purpose only.)This is the computer number: " + target);
				guess(target);
				usersNum.clear();
			}
		});
		// restart button action
		restartButton.setOnMouseClicked(action -> {
			target = (int) Math.floor(Math.random() * 100) + 1;
			feedback.setGraphic(null);
			feedback.setText("A new round begins!");
			total = 5;
		});
		// scene and stage
		VBox pane = new VBox(30, feedback, usersNum, submitButton, restartButton);
		pane.setAlignment(Pos.CENTER);
		pane.setPadding(new Insets(150, 150, 150, 150));
		pane.setStyle("-fx-background-color: #F4FA58;");
		stage.setScene(new Scene(pane));
		stage.show();
	}

	public void guess(int target) {
		String input = usersNum.getText();
		// one round isn't over
		if (total != 1) {
			try {
				int guess = Integer.parseInt(input);
				if (guess < 0 || guess > 100) {
					total--;
					feedback.setGraphic(null);
					feedback.setText("Your number " + guess + " is out of range." + total + " time(s) left.");
					feedback.setWrapText(true);
				} else if (guess > target) {
					total--;
					feedback.setGraphic(null);
					feedback.setText(input + " is too high." + total + " time(s) left.");
					feedback.setWrapText(true);
					guess = Integer.parseInt(input);
				} else if (guess < target) {
					total--;
					feedback.setGraphic(null);
					feedback.setText(input + " is too low." + total + " time(s) left.");
					feedback.setWrapText(true);
					guess = Integer.parseInt(input);
				} else if (guess == target) {
					Image congra = new Image(getClass().getResourceAsStream("congra.png"));
					feedback.setGraphic(new ImageView(congra));
					feedback.setText("You win!!!\nPlay again? Click Restart button.");
				}
			} catch (NumberFormatException ex) {
				System.err.println("Invalid number in argumment.\nPlease enter well-formatted number.");
			}
		} else if (total == 1) {
			// one round is over
			feedback.setText("Game is over. You lose:(\nPlay again? Click Restart button.");
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
